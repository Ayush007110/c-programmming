#include<stdio.h>
int main()
{ int row,col,x[3][3],sum=0;
printf("enter number\n");
for(row=0;row<3;row++)
{ for(col=0;col<3;col++)
{   printf("element is[%d],[%d]=",row,col);
	scanf("%d",&x[row][col]);

}
}
for(row=0;row<3;row++)
{ for(col=0;col<3;col++)
{
	printf("%d\t",x[row][col]);
}
printf("\n");
}
for(row=0;row<3;row++)
{for(col=0;col<3;col++)
 if(row+col==2)
    sum=sum+x[row][col];
}
printf("Sum of antidiagonal %d",sum);

return 0;
}
